package com.techprimers.mongodb.springbootmongodbexample.resource;

import com.techprimers.mongodb.springbootmongodbexample.document.Users;
import com.techprimers.mongodb.springbootmongodbexample.repository.UserRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import javax.validation.Valid;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;



@RestController
@RequestMapping("/rest/users")
public class UsersResource {

    @Autowired
    private UserRepository userRepository;


    @GetMapping("/all")
    public List<Users> getAll() {
        return userRepository.findAll();
    }
    
   
    @GetMapping(value = "/{id}")
    public Users getUserById(@PathVariable("id") String id){
            //ObjectId id) {
    //return userRepository.findByid(id);
    return userRepository.findByname(id);
    }
    
    @PostMapping(value = "/")
    public Users createUser(@Valid @RequestBody Users users) {
    users.setId(ObjectId.get());
    userRepository.save(users);
    return users;
}   
    
    @PutMapping(value = "/{id}")
    public void modifyUserById(@PathVariable("id") ObjectId id, @Valid @RequestBody Users users) {
    users.setId(id);
    userRepository.save(users);
}
    
    @DeleteMapping(value = "/{id}")
    public void deleteUser(@PathVariable ObjectId id) {
    userRepository.delete(userRepository.findByid(id));
}
    
    
}
